package proyectomaven.mavenjenkins;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MavenjenkinsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MavenjenkinsApplication.class, args);
	}

}
