package proyectomaven.mavenjenkins;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MavenjenkinsApplicationTests {

	@Test
	void contextLoads() {
	}

}
